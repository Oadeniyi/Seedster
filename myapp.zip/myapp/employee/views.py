from django.shortcuts import render,render_to_response
from django.http import HttpResponseRedirect
from employee.models import volunteer
from employee.form import volunteerForm
# Create your views here.
def default(request):
	return render(request,'default.html',)
def home(request):
	volunteers =volunteer.objects.all()
	return render(request,'index.html',{'volunteers':volunteers})
def store(request):
	form = volunteerForm()
	if request.method == 'POST':
		form = volunteerForm(request.POST)
		if form.is_valid():
			firstname = form.cleaned_data['firstname']
			lastname = form.cleaned_data['lastname']
			email = form.cleaned_data['email']
			p = volunteer(firstname=firstname, lastname=lastname, email=email)
			p.save()
			return HttpResponseRedirect('/thanks/%i/'% p.pk)
	else:
		return HttpResponseRedirect('/list/add')
def add(request):
	form = volunteerForm
	return render(request,'add.html', {'formv':form})
def success(request, id):
	en = volunteer.objects.get(pk=id)
	return render(request,'thank.html',{'en':en})